---
name: Arshad
picture: https://avatars0.githubusercontent.com/u/124599?v=3&s=460
---

# In Progress

* [Project A] Gumbo beet greens corn soko endive gumbo gourd.

# Pipeline

* [Project A] Turnip greens yarrow ricebean rutabaga endive.
* [Project B] Nori grape silver beet broccoli kombu beet greens fava bean.

# New Board

* [Project A] Task for project A
* [Project B] Task for project B