---
name: John
---

# In Progress

* [Project A] Lipsum dolor sit amet

# Pipeline

* [Project B] Veggie ipsum dolor sit amet
* [Project B] Dolor ipsum sit lipsum

# Next week

* [Project C] Dolor ipsum sit lipsum